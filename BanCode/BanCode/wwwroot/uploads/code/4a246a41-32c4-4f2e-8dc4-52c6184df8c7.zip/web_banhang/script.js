// Menu nhỏ
const bar = document.getElementById('bar');
const nav = document.getElementById('navbar');
const close = document.getElementById('close');


if (bar) {
    bar.addEventListener('click', () => {
        nav.classList.add('active');
    })
}

if (close) {
    close.addEventListener('click', () =>{
        nav.classList.remove('active');
    })
}
function dk(){
    alert("Đăng ký thành công!");
}

// shop
function updateTotal(row) {
    const price = parseInt(row.querySelector('.price').innerText);
    const quantity = parseInt(row.querySelector('.quantity').value);
    const totalCell = row.querySelector('.total');
    const total = price * quantity;
    totalCell.innerText = total.toLocaleString();
    updateGrandTotal();
}

function updateGrandTotal() {
    const totalCells = document.querySelectorAll('.total');
    let grandTotal = 0;
    totalCells.forEach(cell => {
        grandTotal += parseInt(cell.innerText.replace(/,/g, ''));
    });
    document.getElementById('grand-total').innerText = grandTotal.toLocaleString();
}

function increaseQuantity(button) {
    const row = button.closest('tr');
    const input = row.querySelector('.quantity');
    input.value = parseInt(input.value) + 1;
    updateTotal(row);
}

function decreaseQuantity(button) {
    const row = button.closest('tr');
    const input = row.querySelector('.quantity');
    if (parseInt(input.value) > 1) {
        input.value = parseInt(input.value) - 1;
        updateTotal(row);
    }
}

function removeItem(button) {
    const row = button.closest('tr');
    row.remove();
    updateGrandTotal();
}
